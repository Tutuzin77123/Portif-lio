/* ============================================================
   RAZ VERDE — interações
   ============================================================ */
(function () {
  'use strict';

  const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const body = document.body;

  /* ---------- Header fixo (transparente → sólido) ---------- */
  const header = document.getElementById('header');
  const onScroll = () => {
    header.classList.toggle('scrolled', window.scrollY > 40);
  };
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  /* ---------- Parallax sutil do hero ---------- */
  const heroBg = document.getElementById('heroBg');
  let parallaxId = null;
  const parallax = () => {
    if (window.innerWidth < 860 || prefersReduced) return;
    const offset = window.scrollY;
    if (offset < window.innerHeight * 1.4) {
      heroBg.style.transform = 'translate3d(0, ' + offset * 0.28 + 'px, 0)';
    }
  };
  const scheduleParallax = () => {
    if (parallaxId) cancelAnimationFrame(parallaxId);
    parallaxId = requestAnimationFrame(parallax);
  };
  window.addEventListener('scroll', scheduleParallax, { passive: true });

  /* ---------- Scroll reveal (fade-in + slide-up) ---------- */
  const revealEls = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window && !prefersReduced) {
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            io.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: '0px 0px -8% 0px' }
    );
    revealEls.forEach((el) => io.observe(el));
  } else {
    revealEls.forEach((el) => el.classList.add('is-visible'));
  }

  /* ---------- Contadores animados ---------- */
  const counters = document.querySelectorAll('[data-count]');
  const formatNumber = (value) => value.toLocaleString('pt-BR');

  const animateCounter = (el) => {
    const target = parseFloat(el.dataset.count);
    const suffix = el.dataset.suffix || '';
    const duration = 2000;
    const start = performance.now();
    const easeOut = (t) => 1 - Math.pow(1 - t, 3);

    const tick = (now) => {
      const progress = Math.min((now - start) / duration, 1);
      const value = Math.round(target * easeOut(progress));
      el.textContent = formatNumber(value) + (progress === 1 ? suffix : '');
      if (progress < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  };

  if ('IntersectionObserver' in window && !prefersReduced) {
    const countIO = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            animateCounter(entry.target);
            countIO.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.5 }
    );
    counters.forEach((el) => countIO.observe(el));
  } else {
    counters.forEach((el) => {
      el.textContent = formatNumber(parseFloat(el.dataset.count)) + (el.dataset.suffix || '');
    });
  }

  /* ---------- Carrossel de depoimentos ---------- */
  const track = document.getElementById('tTrack');
  const dotsWrap = document.getElementById('tDots');
  const prevBtn = document.getElementById('tPrev');
  const nextBtn = document.getElementById('tNext');
  const slides = Array.from(track.children);
  let current = 0;
  let timer = null;
  const AUTOPLAY = 5000;

  slides.forEach((_, i) => {
    const dot = document.createElement('button');
    dot.className = 'carousel__dot' + (i === 0 ? ' is-active' : '');
    dot.setAttribute('aria-label', 'Ir para depoimento ' + (i + 1));
    dot.addEventListener('click', () => goTo(i, true));
    dotsWrap.appendChild(dot);
  });
  const dots = Array.from(dotsWrap.children);

  const goTo = (index, manual) => {
    current = (index + slides.length) % slides.length;
    track.style.transform = 'translateX(' + -current * 100 + '%)';
    dots.forEach((d, i) => d.classList.toggle('is-active', i === current));
    if (manual) restart();
  };

  const next = () => goTo(current + 1);
  const prev = () => goTo(current - 1);

  const start = () => {
    if (prefersReduced) return;
    timer = setInterval(next, AUTOPLAY);
  };
  const stop = () => { if (timer) { clearInterval(timer); timer = null; } };
  const restart = () => { stop(); start(); };

  nextBtn.addEventListener('click', () => goTo(current + 1, true));
  prevBtn.addEventListener('click', () => goTo(current - 1, true));
  track.closest('.carousel').addEventListener('mouseenter', stop);
  track.closest('.carousel').addEventListener('mouseleave', start);
  start();

  /* ---------- Menu mobile ---------- */
  const navToggle = document.getElementById('navToggle');
  const navClose = document.getElementById('navClose');
  const nav = document.getElementById('nav');

  const setMenu = (open) => {
    nav.classList.toggle('is-open', open);
    body.classList.toggle('menu-open', open);
    navToggle.setAttribute('aria-expanded', String(open));
  };

  navToggle.addEventListener('click', () => setMenu(true));
  navClose.addEventListener('click', () => setMenu(false));
  nav.querySelectorAll('a').forEach((a) =>
    a.addEventListener('click', () => setMenu(false))
  );
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') setMenu(false);
  });

  /* ---------- Fechar menu/CTA ao navegar por âncoras ---------- */
  nav.querySelectorAll('a[href^="#"]').forEach((a) => {
    a.addEventListener('click', (e) => {
      const id = a.getAttribute('href');
      const target = document.querySelector(id);
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: prefersReduced ? 'auto' : 'smooth' });
      }
    });
  });

  /* ---------- Newsletter principal ---------- */
  const newsForm = document.getElementById('newsletterForm');
  const newsMsg = document.getElementById('newsletterMsg');
  const newsEmail = document.getElementById('newsletterEmail');

  newsForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const value = newsEmail.value.trim();
    const valid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
    if (!valid) {
      newsMsg.textContent = 'Hmm, esse e-mail não parece válido. Confere aí?';
      newsMsg.classList.add('is-error');
      return;
    }
    newsMsg.classList.remove('is-error');
    newsMsg.textContent = 'Obrigado! Seu cupom de 10% chegou no seu e-mail. Bem-vinda ao jardim.';
    newsForm.reset();
  });

  /* ---------- Newsletter reduzida do rodapé ---------- */
  const miniForm = document.getElementById('miniForm');
  miniForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const input = miniForm.querySelector('input');
    const value = input.value.trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) return;
    input.value = 'Obrigado por assinar!';
    input.readOnly = true;
    miniForm.querySelector('button').style.display = 'none';
    setTimeout(() => {
      input.value = '';
      input.readOnly = false;
      miniForm.querySelector('button').style.display = '';
    }, 3200);
  });
})();
